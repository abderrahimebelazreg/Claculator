﻿using System;
using System.Net.Http;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using Newtonsoft.Json.Linq; // Install via NuGet: Install-Package Newtonsoft.Json

namespace Calculator
{
    public partial class MainWindow : Window
    {
        private string currentInput = string.Empty;
        private double firstNumber = 0;
        private string selectedOperation = string.Empty;
        private bool isResultDisplayed = false;

        public MainWindow()
        {
            InitializeComponent();

            // Wire up digit buttons
            btnZero.Click += Digit_Click;
            btnOne.Click += Digit_Click;
            btnTwo.Click += Digit_Click;
            btnThree.Click += Digit_Click;
            btnFour.Click += Digit_Click;
            btnFive.Click += Digit_Click;
            btnSix.Click += Digit_Click;
            btnSeven.Click += Digit_Click;
            btnEight.Click += Digit_Click;
            btnNine.Click += Digit_Click;
            btnDecimal.Click += Digit_Click;

            // Wire up operation buttons
            btnAdd.Click += Operation_Click;
            btnSubtract.Click += Operation_Click;
            btnMultiply.Click += Operation_Click;
            btnDivide.Click += Operation_Click;

            // Equals button
            btnEquals.Click += Equals_Click;

            // Clear button
            btnClear.Click += Clear_Click;
        }

        private void Digit_Click(object sender, RoutedEventArgs e)
        {
            if (isResultDisplayed)
            {
                currentInput = string.Empty;
                isResultDisplayed = false;
            }

            Button button = sender as Button;
            string value = button.Content.ToString();

            if (value == "." && currentInput.Contains(".")) return;

            if (currentInput == "0" && value != ".") currentInput = string.Empty;

            currentInput += value;
            displayLabel.Content = currentInput;
        }

        private void Operation_Click(object sender, RoutedEventArgs e)
        {
            if (!string.IsNullOrEmpty(currentInput))
            {
                firstNumber = double.Parse(currentInput);
                currentInput = string.Empty;
            }

            Button button = sender as Button;
            selectedOperation = button.Content.ToString();
            isResultDisplayed = false;
        }

        private async void Equals_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrEmpty(currentInput) || string.IsNullOrEmpty(selectedOperation)) return;

            double secondNumber = double.Parse(currentInput);

            string apiOp = string.Empty;
            switch (selectedOperation)
            {
                case "+": apiOp = "add"; break;
                case "-": apiOp = "subtract"; break;
                case "*": apiOp = "multiply"; break;
                case "÷": apiOp = "divide"; break;
                default: return;
            }

            using (HttpClient client = new HttpClient())
            {
                string url = $"http://localhost:443/calculate?a={firstNumber}&b={secondNumber}&op={apiOp}"; // Use https:// if API is SSL-enabled

                try
                {
                    HttpResponseMessage response = await client.GetAsync(url);
                    response.EnsureSuccessStatusCode();
                    string responseBody = await response.Content.ReadAsStringAsync();

                    JObject json = JObject.Parse(responseBody);
                    double? result = (double?)json["result"]; // Use nullable to avoid null reference error
                    if (result.HasValue)
                    {
                        displayLabel.Content = result.Value.ToString();
                        currentInput = result.Value.ToString();
                        isResultDisplayed = true;
                        selectedOperation = string.Empty;
                    }
                    else
                    {
                        displayLabel.Content = "Error";
                    }
                }
                catch (HttpRequestException ex) when ((int?)ex.StatusCode == 400)
                {
                    displayLabel.Content = "Error: Division by zero";
                }
                catch (Exception)
                {
                    displayLabel.Content = "Error";
                }
            }
        }

        private void Clear_Click(object sender, RoutedEventArgs e)
        {
            currentInput = string.Empty;
            firstNumber = 0;
            selectedOperation = string.Empty;
            isResultDisplayed = false;
            displayLabel.Content = "0";
        }
    }
}